import React from "react";
import { Menu } from "../../components/Menu";
import { Prof } from "../../components/Prof";
import "./style.css";

export const Userpage = () => {
  return (
    <div className="userpage">
      <div className="window-wrapper">
        <div className="window">
          <div className="overlap">
            <div className="desk-bg">
              <div className="overlap-group">
                <img className="katie-smith" alt="Katie smith" src="/img/katie-smith-uqs1802d0cq-unsplash-1.png" />
                <div className="bg-overlay" />
              </div>
            </div>
            <div className="app-window">
              <div className="frame">
                <div className="div">
                  <div className="rectangle" />
                  <div className="felhasznlsfelulet">
                    <div className="frame-2">
                      <div className="text-wrapper">felhasználónév</div>
                      <div className="text-wrapper-2">e-mail cím</div>
                    </div>
                  </div>
                  <div className="rectangle-2" />
                  <div className="frame-3">
                    <img className="img" alt="Frame" src="/img/frame-331-2.svg" />
                    <img className="frame-4" alt="Frame" src="/img/frame-331-1.svg" />
                  </div>
                  <div className="frame-wrapper">
                    <img className="frame-5" alt="Frame" src="/img/frame-331.svg" />
                  </div>
                  <Menu className="menu-instance" />
                </div>
              </div>
              <img className="logo" alt="Logo" src="/img/logo.svg" />
              <Prof className="prof-1" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
