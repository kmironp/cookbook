import React from "react";
import { Group } from "../../components/Group";
import { Prof } from "../../components/Prof";
import { ProfWrapper } from "../../components/ProfWrapper";
import { StandardButton } from "../../components/StandardButton";
import "./style.css";

export const Register = () => {
  return (
    <div className="register">
      <div className="overlap-wrapper">
        <div className="overlap-group">
          <div className="overlap-group-wrapper">
            <div className="overlap-group">
              <div className="overlap-group-wrapper">
                <div className="overlap-group">
                  <img className="katie-smith" alt="Katie smith" src="/img/katie-smith-uqs1802d0cq-unsplash-1.png" />
                  <div className="bg-overlay" />
                </div>
              </div>
              <div className="app-window">
                <div className="overlap">
                  <div className="form-section">
                    <div className="div-wrapper">
                      <div className="text-wrapper">Create an account</div>
                    </div>
                    <div className="div">
                      <div className="text-wrapper-2">Login</div>
                      <StandardButton
                        className="standard-button-instance"
                        divClassName="design-component-instance-node"
                        text="Register"
                      />
                    </div>
                    <button className="standard-button-wrapper">
                      <button className="button">
                        <div className="OK-wrapper">
                          <div className="OK-2">Sign up</div>
                        </div>
                      </button>
                    </button>
                    <div className="frame">
                      <div className="frame-2">
                        <div className="form-input">
                          <img className="vector" alt="Vector" src="/img/vector-1-4.svg" />
                          <div className="username-or-input">Email</div>
                        </div>
                        <div className="form-input">
                          <img className="vector" alt="Vector" src="/img/vector-1-4.svg" />
                          <div className="username-or-input">Username</div>
                        </div>
                        <div className="form-input">
                          <img className="vector" alt="Vector" src="/img/vector-1-4.svg" />
                          <div className="username-or-input">Password</div>
                        </div>
                        <div className="form-input">
                          <img className="vector" alt="Vector" src="/img/vector-1-4.svg" />
                          <div className="username-or-input">Password again</div>
                        </div>
                      </div>
                      <div className="form-input">
                        <div className="username-or-input">Choose a profile:</div>
                      </div>
                    </div>
                    <img className="logo" alt="Logo" src="/img/logo.svg" />
                  </div>
                  <div className="hero-section" />
                </div>
              </div>
            </div>
          </div>
          <Prof className="prof-0" />
          <ProfWrapper className="prof-1" />
          <Group />
        </div>
      </div>
    </div>
  );
};
