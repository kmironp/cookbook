import { StandardButton } from ".";

export default {
  title: "Components/StandardButton",
  component: StandardButton,
};

export const Default = {
  args: {
    className: {},
    divClassName: {},
    text: "OK",
  },
};
