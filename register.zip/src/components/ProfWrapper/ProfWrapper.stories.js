import { ProfWrapper } from ".";

export default {
  title: "Components/ProfWrapper",
  component: ProfWrapper,
};

export const Default = {
  args: {
    className: {},
  },
};
