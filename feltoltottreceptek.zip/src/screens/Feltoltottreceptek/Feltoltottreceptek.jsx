import React from "react";
import { Frame } from "../../components/Frame";
import { RecCard } from "../../components/RecCard";
import "./style.css";

export const Feltoltottreceptek = () => {
  return (
    <div className="feltoltottreceptek">
      <div className="overlap-wrapper">
        <div className="div">
          <div className="overlap-group-wrapper">
            <div className="div">
              <div className="overlap-group-wrapper">
                <div className="div">
                  <img className="katie-smith" alt="Katie smith" src="/img/katie-smith-uqs1802d0cq-unsplash-1.png" />
                  <div className="bg-overlay" />
                </div>
              </div>
              <div className="app-window">
                <div className="main-window" />
              </div>
            </div>
          </div>
          <img className="img" alt="Logo" src="/img/logo-1.png" />
          <div className="div-wrapper">
            <div className="overlap">
              <RecCard className="rec-card-instance" />
              <RecCard className="design-component-instance-node" />
              <RecCard className="rec-card-2" />
              <div className="frame-2">
                <div className="text-wrapper-2">Általam feltöltött receptek</div>
              </div>
            </div>
          </div>
          <Frame className="frame-347" />
        </div>
      </div>
    </div>
  );
};
