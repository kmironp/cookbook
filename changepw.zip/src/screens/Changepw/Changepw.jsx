import React from "react";
import { Component } from "../../components/Component";
import { Frame } from "../../components/Frame";
import { Menu } from "../../components/Menu";
import { Prof } from "../../components/Prof";
import "./style.css";

export const Changepw = () => {
  return (
    <div className="changepw">
      <div className="overlap-wrapper">
        <div className="overlap-group">
          <div className="overlap-group-wrapper">
            <div className="overlap-group">
              <div className="overlap-group-wrapper">
                <div className="overlap-group">
                  <img className="katie-smith" alt="Katie smith" src="/img/katie-smith-uqs1802d0cq-unsplash-1-1.png" />
                  <div className="bg-overlay" />
                </div>
              </div>
              <div className="app-window">
                <div className="div-wrapper">
                  <div className="div">
                    <div className="rectangle" />
                    <div className="felhasznlsfelulet">
                      <div className="frame-2">
                        <div className="text-wrapper">felhasználónév</div>
                        <div className="text-wrapper-2">e-mail cím</div>
                      </div>
                    </div>
                    <Menu className="menu-instance" />
                    <Component className="component-33" />
                  </div>
                </div>
                <img className="img" alt="Logo" src="/img/logo-2.svg" />
                <Prof className="prof-1" />
              </div>
            </div>
          </div>
          <div className="overlap-group-wrapper">
            <div className="overlap-group">
              <div className="overlap-group-wrapper">
                <div className="overlap-group">
                  <img className="katie-smith" alt="Katie smith" src="/img/katie-smith-uqs1802d0cq-unsplash-1-1.png" />
                  <div className="bg-overlay" />
                </div>
              </div>
              <div className="app-window">
                <div className="div-wrapper">
                  <div className="div">
                    <div className="overlap">
                      <div className="frame-wrapper">
                        <div className="frame-2">
                          <div className="text-wrapper">felhasználónév</div>
                          <div className="text-wrapper-2">e-mail cím</div>
                        </div>
                      </div>
                      <Component className="component-33-instance" divClassName="component-instance" />
                      <Component
                        className="design-component-instance-node"
                        divClassName="component-instance"
                        text="Új jelszó még egyszer:"
                      />
                      <Component className="component-2" divClassName="component-instance" text="Új jelszó:" />
                      <div className="rectangle-2" />
                      <div className="rectangle-3" />
                      <div className="rectangle-4" />
                    </div>
                    <Frame className="frame-347" visible={false} />
                  </div>
                </div>
                <Prof className="prof-1" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
