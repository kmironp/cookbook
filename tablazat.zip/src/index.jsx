import React from "react";
import ReactDOMClient from "react-dom/client";
import { Tablazat } from "./screens/Tablazat";

const app = document.getElementById("app");
const root = ReactDOMClient.createRoot(app);
root.render(<Tablazat />);
