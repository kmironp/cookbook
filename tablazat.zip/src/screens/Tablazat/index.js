export { Tablazat } from "./Tablazat";
