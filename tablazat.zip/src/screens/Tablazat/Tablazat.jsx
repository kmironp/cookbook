import React from "react";
import { Component } from "../../components/Component";
import { Frame } from "../../components/Frame";
import "./style.css";

export const Tablazat = () => {
  return (
    <div className="tablazat">
      <div className="overlap-wrapper">
        <div className="overlap-group">
          <div className="overlap-group-wrapper">
            <div className="overlap-group">
              <div className="overlap-group-wrapper">
                <div className="overlap-group">
                  <img className="katie-smith" alt="Katie smith" src="/img/katie-smith-uqs1802d0cq-unsplash-1.png" />
                  <div className="bg-overlay" />
                </div>
              </div>
              <div className="app-window">
                <div className="main-window" />
              </div>
              <div className="rectangle" />
              <div className="frame-wrapper">
                <div className="div-wrapper">
                  <div className="text-wrapper">Kategória név</div>
                </div>
              </div>
            </div>
          </div>
          <div className="fejlc">
            <div className="div">
              <div className="text-wrapper-2">Alapanyag</div>
            </div>
            <div className="frame-2">
              <div className="text-wrapper-2">Energia</div>
            </div>
            <div className="frame-3">
              <div className="text-wrapper-2">Fehérje</div>
            </div>
            <div className="frame-4">
              <div className="text-wrapper-2">Zsír</div>
            </div>
            <div className="frame-5">
              <div className="text-wrapper-2">Szénhidrát</div>
            </div>
            <div className="frame-6">
              <div className="text-wrapper-2">GI</div>
            </div>
          </div>
          <div className="row">
            <div className="overlap">
              <Component className="component-27" />
              <Component className="component-27-instance" divClassName="component-instance" text="energia" />
              <Component className="design-component-instance-node" divClassName="component-2" text="feherje" />
              <Component className="component-3" divClassName="component-4" text="zsir" />
              <Component className="component-5" divClassName="component-6" text="szenhidrat" />
              <Component className="component-7" divClassName="component-8" text="gi" />
            </div>
          </div>
          <Frame className="frame-347" />
        </div>
      </div>
    </div>
  );
};
