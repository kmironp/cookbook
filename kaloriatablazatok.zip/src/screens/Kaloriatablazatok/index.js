export { Kaloriatablazatok } from "./Kaloriatablazatok";
