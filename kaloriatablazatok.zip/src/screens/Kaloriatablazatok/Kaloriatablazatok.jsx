import React from "react";
import { Frame } from "../../components/Frame";
import "./style.css";

export const Kaloriatablazatok = () => {
  return (
    <div className="kaloriatablazatok">
      <div className="overlap-wrapper">
        <div className="overlap-group">
          <div className="overlap-group-wrapper">
            <div className="overlap-group">
              <div className="overlap-group-wrapper">
                <div className="overlap-group">
                  <img className="katie-smith" alt="Katie smith" src="/img/katie-smith-uqs1802d0cq-unsplash-1.png" />
                  <div className="bg-overlay" />
                </div>
              </div>
              <div className="app-window">
                <div className="main-window" />
              </div>
            </div>
          </div>
          <div className="rectangle" />
          <img className="img" alt="Frame" src="/img/frame-313.png" />
          <Frame className="frame-347" />
        </div>
      </div>
    </div>
  );
};
