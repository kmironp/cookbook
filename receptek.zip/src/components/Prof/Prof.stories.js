import { Prof } from ".";

export default {
  title: "Components/Prof",
  component: Prof,
};

export const Default = {
  args: {
    className: {},
  },
};
