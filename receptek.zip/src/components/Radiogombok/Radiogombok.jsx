/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const Radiogombok = ({ state, name, className }) => {
  return (
    <div className={`radiogombok ${className}`}>
      <div className={`circle ${state}`}>
        <div className="ellipse" />
      </div>
      <div className="kihagyja">
        {name === "kihagy" && <>Kihagyja</>}

        {name === "tart" && <>Tartalmazza</>}
      </div>
    </div>
  );
};

Radiogombok.propTypes = {
  state: PropTypes.oneOf(["default", "kivalasztva"]),
  name: PropTypes.oneOf(["kihagy", "tart"]),
};
