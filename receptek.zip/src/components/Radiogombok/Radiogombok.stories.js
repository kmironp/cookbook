import { Radiogombok } from ".";

export default {
  title: "Components/Radiogombok",
  component: Radiogombok,
  argTypes: {
    state: {
      options: ["default", "kivalasztva"],
      control: { type: "select" },
    },
    name: {
      options: ["kihagy", "tart"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    state: "default",
    name: "kihagy",
    className: {},
  },
};
