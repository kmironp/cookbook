import { MenuWrapper } from ".";

export default {
  title: "Components/MenuWrapper",
  component: MenuWrapper,
};

export const Default = {
  args: {
    className: {},
  },
};
