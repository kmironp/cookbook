import React from "react";
import { Frame } from "../../components/Frame";
import { MenuWrapper } from "../../components/MenuWrapper";
import { Prof } from "../../components/Prof";
import { Radiogombok } from "../../components/Radiogombok";
import { RecCard } from "../../components/RecCard";
import "./style.css";

export const Receptek = () => {
  return (
    <div className="receptek">
      <div className="overlap-wrapper">
        <div className="overlap-group-2">
          <div className="overlap-group-wrapper">
            <div className="overlap-group-2">
              <div className="overlap-group-wrapper">
                <div className="overlap-group-2">
                  <img className="katie-smith" alt="Katie smith" src="/img/katie-smith-uqs1802d0cq-unsplash-1.png" />
                  <div className="bg-overlay" />
                </div>
              </div>
              <div className="app-window">
                <div className="main-window" />
              </div>
            </div>
          </div>
          <Prof className="prof-1" />
          <img className="logo" alt="Logo" src="/img/logo.svg" />
          <div className="rectangle-2" />
          <div className="frame-2" />
          <RecCard className="rec-card-instance" />
          <RecCard className="design-component-instance-node" />
          <RecCard className="rec-card-2" />
          <MenuWrapper className="menu-2" />
          <div className="hatter-kereseshez" />
          <div className="rectangle-3" />
          <div className="rectangle-4" />
          <div className="rectangle-5" />
          <div className="rectangle-6" />
          <div className="text-wrapper-2">gluténmentes</div>
          <div className="text-wrapper-3">laktózmentes</div>
          <div className="text-wrapper-4">vegetáriánus</div>
          <div className="text-wrapper-5">vegán</div>
          <div className="hozzavalo-beirasa">
            <div className="text-wrapper-6">Hozzávaló_neve</div>
          </div>
          <div className="kereso-gomb">
            <Frame className="frame-8" text="Keresés" />
          </div>
          <div className="text-wrapper-7">Receptek keresése</div>
          <img className="elvalaszto" alt="Elvalaszto" src="/img/elvalaszto.svg" />
          <div className="tart-kihagy">
            <div className="div-2">
              <Radiogombok className="radiogombok-instance" name="tart" state="default" />
              <Radiogombok className="radiogombok-instance" name="kihagy" state="kivalasztva" />
            </div>
          </div>
          <div className="tart-tart">
            <div className="div-2">
              <Radiogombok className="radiogombok-instance" name="tart" state="kivalasztva" />
              <Radiogombok className="radiogombok-instance" name="kihagy" state="default" />
            </div>
          </div>
          <div className="tart-alap">
            <div className="div-2">
              <Radiogombok className="radiogombok-instance" name="tart" state="default" />
              <Radiogombok className="radiogombok-instance" name="kihagy" state="default" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
