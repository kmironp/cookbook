export { Receptek } from "./Receptek";
