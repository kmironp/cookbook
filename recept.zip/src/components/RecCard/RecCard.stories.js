import { RecCard } from ".";

export default {
  title: "Components/RecCard",
  component: RecCard,
};

export const Default = {
  args: {
    className: {},
    overlapGroupClassName: {},
    rectangleClassName: {},
    divClassName: {},
  },
};
