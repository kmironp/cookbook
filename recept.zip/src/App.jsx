import React from "react";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { Recept } from "./screens/Recept";

const router = createBrowserRouter([
  {
    path: "/*",
    element: <Recept />,
  },
]);

export const App = () => {
  return <RouterProvider router={router} />;
};
