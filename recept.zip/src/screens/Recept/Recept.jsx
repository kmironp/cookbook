import React from "react";
import { Frame } from "../../components/Frame";
import { RecCard } from "../../components/RecCard";
import "./style.css";

export const Recept = () => {
  return (
    <div className="recept">
      <div className="overlap-wrapper">
        <div className="overlap">
          <div className="window">
            <div className="div">
              <div className="desk-bg">
                <div className="overlap-group-2">
                  <img className="katie-smith" alt="Katie smith" src="/img/katie-smith-uqs1802d0cq-unsplash-1.png" />
                  <div className="bg-overlay" />
                </div>
              </div>
              <div className="app-window">
                <div className="main-window" />
              </div>
              <div className="rectangle-2" />
              <div className="text-wrapper-2">hozzavalok</div>
              <div className="text-wrapper-3">Elkészítés:</div>
              <div className="text-wrapper-4">elkeszites</div>
            </div>
          </div>
          <RecCard
            className="rec-card-instance"
            divClassName="rec-card-3"
            overlapGroupClassName="design-component-instance-node"
            rectangleClassName="rec-card-2"
          />
          <div className="text-wrapper-5">Hozzávalók:</div>
          <div className="text-wrapper-6">Adagok száma:</div>
          <Frame className="frame-347" />
        </div>
      </div>
    </div>
  );
};
