import React from "react";
import { Frame } from "../../components/Frame";
import "./style.css";

export const Feltoltes = () => {
  return (
    <div className="feltoltes">
      <div className="overlap-wrapper">
        <div className="overlap">
          <div className="overlap-group-wrapper">
            <div className="overlap-group">
              <div className="overlap-group-wrapper">
                <div className="overlap-group">
                  <img className="katie-smith" alt="Katie smith" src="/img/katie-smith-uqs1802d0cq-unsplash-1.png" />
                  <div className="bg-overlay" />
                </div>
              </div>
              <div className="app-window">
                <div className="main-window" />
              </div>
              <div className="div-wrapper">
                <div className="div">
                  <div className="frame-2">
                    <div className="text-wrapper-2">+</div>
                  </div>
                  <div className="frame-3">
                    <div className="text-wrapper-3">Nyilvános?</div>
                    <div className="circle">
                      <div className="ellipse" />
                    </div>
                  </div>
                  <div className="text-wrapper-4">Elkészítés:</div>
                  <div className="frame-4">
                    <div className="text-wrapper-5">Recept neve:</div>
                    <div className="text-wrapper-6">Adagok száma:</div>
                    <div className="text-wrapper-6">Hozzávalók:</div>
                  </div>
                  <div className="overlap-2">
                    <div className="rectangle" />
                    <div className="text-wrapper-7">receptnev</div>
                  </div>
                  <div className="overlap-3">
                    <div className="rectangle" />
                    <div className="text-wrapper-7">adagszam</div>
                  </div>
                  <div className="group-2">
                    <div className="overlap-group-2">
                      <div className="rectangle-2" />
                      <div className="text-wrapper-8">hozzavalo</div>
                    </div>
                  </div>
                  <div className="group-3">
                    <div className="overlap-4">
                      <div className="rectangle-3" />
                      <div className="text-wrapper-9">mnnysg</div>
                    </div>
                  </div>
                  <div className="group-4">
                    <div className="overlap-4">
                      <div className="rectangle-3" />
                      <div className="text-wrapper-9">mnnysg</div>
                    </div>
                  </div>
                  <div className="group-5">
                    <div className="overlap-4">
                      <div className="rectangle-3" />
                      <div className="text-wrapper-9">mnnysg</div>
                    </div>
                  </div>
                  <div className="group-6">
                    <div className="overlap-4">
                      <div className="rectangle-3" />
                      <div className="text-wrapper-9">mnnysg</div>
                    </div>
                  </div>
                  <div className="group-7">
                    <div className="overlap-5">
                      <div className="text-wrapper-10">hozzavalo</div>
                    </div>
                  </div>
                  <div className="frame-5">
                    <img className="img" alt="Rectangle" src="/img/rectangle-82.svg" />
                    <div className="text-wrapper-11">szoveg</div>
                  </div>
                  <div className="frame-6">
                    <div className="text-wrapper-12">Feltöltés</div>
                  </div>
                  <div className="text-wrapper-13">Recept feltöltése</div>
                </div>
              </div>
            </div>
          </div>
          <div className="rectangle-4" />
          <Frame className="frame-347" />
        </div>
      </div>
    </div>
  );
};
