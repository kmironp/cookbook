import React from "react";
import { StandardButton } from "../../components/StandardButton";
import "./style.css";

export const Login = () => {
  return (
    <div className="login">
      <div className="window-wrapper">
        <div className="window">
          <div className="overlap">
            <div className="desk-bg">
              <div className="overlap-group">
                <img className="katie-smith" alt="Katie smith" src="/img/katie-smith-uqs1802d0cq-unsplash-1.png" />
                <div className="bg-overlay" />
              </div>
            </div>
            <div className="app-window">
              <div className="div">
                <div className="form-section">
                  <div className="group">
                    <div className="text-wrapper">Welcome back!</div>
                  </div>
                  <div className="group-2">
                    <div className="text-wrapper-2">Register</div>
                    <div className="frame">
                      <div className="text-wrapper-3">Login</div>
                    </div>
                  </div>
                  <div className="standard-button-wrapper">
                    <StandardButton
                      className="standard-button-instance"
                      divClassName="design-component-instance-node"
                      text="Log in"
                    />
                  </div>
                  <div className="frame-2">
                    <div className="frame-3">
                      <div className="form-input">
                        <img className="vector" alt="Vector" src="/img/vector-1-2.svg" />
                        <div className="username-or-input">Email</div>
                      </div>
                      <div className="form-input">
                        <img className="vector" alt="Vector" src="/img/vector-1-2.svg" />
                        <div className="username-or-input">Password</div>
                      </div>
                    </div>
                    <div className="form-input" />
                  </div>
                  <img className="logo" alt="Logo" src="/img/logo.svg" />
                </div>
                <div className="hero-section" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
