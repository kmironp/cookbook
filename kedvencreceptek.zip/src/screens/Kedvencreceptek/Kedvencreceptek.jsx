import React from "react";
import { Frame } from "../../components/Frame";
import { RecCard } from "../../components/RecCard";
import "./style.css";

export const Kedvencreceptek = () => {
  return (
    <div className="kedvencreceptek">
      <div className="overlap-wrapper">
        <div className="div">
          <div className="desk-bg">
            <div className="div">
              <img className="katie-smith" alt="Katie smith" src="/img/katie-smith-uqs1802d0cq-unsplash-1.png" />
              <div className="bg-overlay" />
            </div>
          </div>
          <div className="app-window">
            <div className="overlap">
              <div className="rectangle-wrapper">
                <div className="rectangle-2" />
              </div>
              <div className="div-wrapper">
                <div className="text-wrapper-2">Kedvenc receptjeim</div>
              </div>
              <RecCard className="rec-card-instance" />
              <RecCard className="design-component-instance-node" />
              <RecCard className="rec-card-2" />
            </div>
          </div>
          <Frame className="frame-347" />
        </div>
      </div>
    </div>
  );
};
