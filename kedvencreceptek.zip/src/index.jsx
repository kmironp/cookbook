import React from "react";
import ReactDOMClient from "react-dom/client";
import { Kedvencreceptek } from "./screens/Kedvencreceptek";

const app = document.getElementById("app");
const root = ReactDOMClient.createRoot(app);
root.render(<Kedvencreceptek />);
